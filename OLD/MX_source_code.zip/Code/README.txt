This folder contains the source code for Matrix Explorer (MX). 

Running MX locally requires an updated version of R as well as the following packages: shiny, ggplot2, robustbase, reshape, grid, htmltools, fastcluster, ggdendro, 
gtable, tsne, RColorBrewer, DT, data.table. To run MX locally, start R, change the working direcroty to the directory the server.r, ui.r, and global.r files are in, and run the command runApp(). This should start MX. 

To recreate the images shown in the paper, upload the iris dataset found in the sample_sets sub-folder and navigate to the relevant tab.
